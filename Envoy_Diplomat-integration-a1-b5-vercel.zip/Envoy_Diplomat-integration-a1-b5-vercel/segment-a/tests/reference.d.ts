declare module 'frozen-b:*';
